﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
internal class program2
{
    static void Main(string[] args)
    {
        Console.WriteLine("введите число от 5 до 10");
        int num = Convert.ToInt32(Console.ReadLine());

        if (num <= 10 & num >= 5)
        {
            Console.WriteLine("число больше 5 и меньше 10");
        }
        else
        {
            Console.WriteLine("неизвестное число");
        }
    }
}
