﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace PZ23_KIRILLOV_POLYAKOV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textboxLastName.Text) || string.IsNullOrEmpty(textBox8.Text) ||
           string.IsNullOrEmpty(textboxAddress1.Text) || string.IsNullOrEmpty(textboxAddress.Text) ||
           string.IsNullOrEmpty(textboxAddress2.Text) || string.IsNullOrEmpty(textboxAddress3.Text) ||
           string.IsNullOrEmpty(numericUpDown1.Text))
            {
                lblError.Text = "Не все данные введены!";
            }
            else
            {
                string gender = "";
                if (radioButton1.Checked)
                {
                    gender = "Мужской";
                }
                else if (radioButton2.Checked)
                {
                    gender = "Женский";
                }
                string filePath = @"Страхователи.txt";
                using (StreamWriter sw = File.AppendText(filePath))
                {
                    sw.WriteLine("Страхователи ");
                    sw.WriteLine("Фамилия: " + textboxLastName.Text);
                    sw.WriteLine("Имя: " + textBox8.Text);
                    sw.WriteLine("Город " + textboxAddress1.Text);
                    sw.WriteLine("Улица " + textboxAddress.Text);
                    sw.WriteLine("Дом " + textboxAddress2.Text);
                    sw.WriteLine("Кв " + textboxAddress3.Text);
                    sw.WriteLine("Пол: " + gender);
                    sw.WriteLine("Срок страхования: " + numericUpDown1.Value.ToString());
                    sw.WriteLine("Вид страхования: " + comboBox1.SelectedItem.ToString());
                    sw.WriteLine();
                }
                MessageBox.Show("Данные успешно сохранены в файл!");

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}