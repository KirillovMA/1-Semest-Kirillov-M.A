﻿using System;
namespace Programm_2
{
    class Programm_3
    {
        static void Main()
        {
            int x = 9;
            double num_1 , num_2 ;
            num_1 = Math.Pow(x, 2); num_1 = num_1 * 2;
            num_2 = Math.Round(Math.Sign(x) * Math.Pow(Math.Abs(x), 1 / 3.0f), 2); num_2 = num_2 * 3;
            Console.WriteLine(num_1 - num_2);

        }
    }
}