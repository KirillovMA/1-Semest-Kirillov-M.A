﻿using System;
namespace Programm_2
{
    class Programm_2
    {
        static void Main()
        {
            Console.WriteLine("Введите a: ");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            double c2 = (Math.Pow(a, 2) + Math.Pow(b, 2));
            Console.WriteLine("По теореме пифагора c в квадрате: " + c2);
        }
    }
}