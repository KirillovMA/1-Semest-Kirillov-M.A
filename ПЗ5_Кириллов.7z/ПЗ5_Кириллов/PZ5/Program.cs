﻿using System;
namespace Programm_1
{
    class Programm_1
    {
        static void Main()
        {
            Console.WriteLine("Введите первое число: ");
            int num_1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите второе число: ");
            int num_2 = Convert.ToInt32(Console.ReadLine());

            int max = Math.Max(num_1, num_2);
            Console.WriteLine("Максимальное число: " + max);
        }
    }
}