﻿using System;
namespace Programm_5
{
    class Program
    {
        static void Main()
        {
            double x = 2;
            double y = 5;
            double nX = -x;
            double nY = -y;
            double nXY = -x * -y;
            double otvet = nX - nY / (1 + nXY);
            Console.WriteLine($"Ответ {otvet}");
        }
    }
}