﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        string filePath = "numbers.txt";

        int[] numbers = new int[500];
        for (int i = 0; i < numbers.Length; i++)
        {
            numbers[i] = i + 1;
        }

        string numbersString = string.Join(",", numbers);

        File.WriteAllText(filePath, numbersString);

    }
}