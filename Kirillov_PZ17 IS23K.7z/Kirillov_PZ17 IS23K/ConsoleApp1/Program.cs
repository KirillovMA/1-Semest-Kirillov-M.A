﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        string filePath = "colors.txt";

        
            string[] lines = File.ReadAllLines(filePath);

            int maxLength = 0;
            foreach (string line in lines)
            {
                if (line.Length > maxLength)
                {
                    maxLength = line.Length;
                }
            }

            Console.WriteLine("Длина самой длинной строки colors.txt: " + maxLength);
        
    }
}