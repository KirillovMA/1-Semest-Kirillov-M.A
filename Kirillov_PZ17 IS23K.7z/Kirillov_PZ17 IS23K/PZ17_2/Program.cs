﻿using System;
using System.IO;
using System.Text;
using System.Xml.Schema;
namespace programm
{
    class Programm
    {
        static void Main(string[] args)
        {
            string[] colors = { "red", "green", "black", "white", "blue" };

            string filePath = "colors.txt";


            File.WriteAllLines(filePath, colors);
        }
    }
}