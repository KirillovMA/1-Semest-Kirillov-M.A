﻿namespace WindowsFormsApp1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cB2 = new System.Windows.Forms.RadioButton();
            this.cBl = new System.Windows.Forms.RadioButton();
            this.rBl = new System.Windows.Forms.CheckBox();
            this.rB2 = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cB2);
            this.groupBox1.Controls.Add(this.cBl);
            this.groupBox1.Location = new System.Drawing.Point(115, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Режим работы";
            // 
            // cB2
            // 
            this.cB2.AutoSize = true;
            this.cB2.Location = new System.Drawing.Point(29, 54);
            this.cB2.Name = "cB2";
            this.cB2.Size = new System.Drawing.Size(111, 17);
            this.cB2.TabIndex = 1;
            this.cB2.TabStop = true;
            this.cB2.Text = "Меньше предела";
            this.cB2.UseVisualStyleBackColor = true;
            // 
            // cBl
            // 
            this.cBl.AutoSize = true;
            this.cBl.Location = new System.Drawing.Point(29, 31);
            this.cBl.Name = "cBl";
            this.cBl.Size = new System.Drawing.Size(109, 17);
            this.cBl.TabIndex = 0;
            this.cBl.TabStop = true;
            this.cBl.Text = "Больше предела";
            this.cBl.UseVisualStyleBackColor = true;
            this.cBl.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // rBl
            // 
            this.rBl.AutoSize = true;
            this.rBl.Location = new System.Drawing.Point(429, 110);
            this.rBl.Name = "rBl";
            this.rBl.Size = new System.Drawing.Size(60, 17);
            this.rBl.TabIndex = 1;
            this.rBl.Text = "Сумма";
            this.rBl.UseVisualStyleBackColor = true;
            // 
            // rB2
            // 
            this.rB2.AutoSize = true;
            this.rB2.Location = new System.Drawing.Point(429, 143);
            this.rB2.Name = "rB2";
            this.rB2.Size = new System.Drawing.Size(100, 17);
            this.rB2.TabIndex = 2;
            this.rB2.Text = "Произведение";
            this.rB2.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 338);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Предел";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(188, 338);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 20);
            this.textBox1.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(441, 338);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(159, 52);
            this.button1.TabIndex = 5;
            this.button1.Text = "Спрятать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rB2);
            this.Controls.Add(this.rBl);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.RadioButton cB2;
        public System.Windows.Forms.RadioButton cBl;
        public System.Windows.Forms.CheckBox rBl;
        public System.Windows.Forms.CheckBox rB2;
        public System.Windows.Forms.TextBox textBox1;
    }
}