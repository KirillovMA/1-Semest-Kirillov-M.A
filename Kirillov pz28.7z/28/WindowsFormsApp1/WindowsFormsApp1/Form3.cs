﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form3 : Form
    {
        public Form2 f22;
        private int result = 0; 
        private int result1 = 1;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            string[] StlArr;
            string rl;
            double[] x;
            double z, sum = 0, pr = 1;
            rl = textBox1.Text;
            StlArr = rl.Split(';');
            x = new double[StlArr.Length];
            z = Convert.ToDouble(f22.textBox1.Text);
            for (int i = 0; i < x.Length; i++)
                x[i] = Convert.ToDouble(StlArr[i]);
            if (f22.cBl.Checked)
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (f22.rBl.Checked && x[i] >= z) sum += x[i];
                    if (f22.rB2.Checked && x[i] < z) pr += x[i];
                }
            }
            if (f22.cB2.Checked)
            {
                for (int i = 0; i < x.Length; i++)
                {
                    if (f22.rBl.Checked && x[i] >= z) pr *= x[i];
                    if (f22.rB2.Checked && x[i] < z) pr *= x[i];
                }
            }
            label6.Text = "" + sum;
            label7.Text = "" + pr;
        }
        private void label4_Click(object sender, EventArgs e)
        {
            
        }
        private void label5_Click(object sender, EventArgs e)
        {
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
