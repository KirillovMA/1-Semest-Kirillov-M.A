﻿using System;
namespace Programm_2
{
    class Programm
    {
        static void Main() 
        {
            string str;
            str = str = "Фамилия: {{ {0} }}, дата рождения: {{ {1} }}, место рождения: {{ {2} }}, Bозраст: {{ {3} }}";
            str = string.Format(str, "Кириллов", "02.11.2006", "г.Курск", 17);
            Console.WriteLine(str);
            string str1;
            str1 = str1 = "Фамилия: {{ {0} }}, дата рождения: {{ {1} }}, место рождения: {{ {2} }}, Bозраст: {{ {3} }}";
            str1 = string.Format(str1, "Поляков", "31.10.2006", "г.Курск", 17);
            Console.WriteLine(str1);
        }
    }
}