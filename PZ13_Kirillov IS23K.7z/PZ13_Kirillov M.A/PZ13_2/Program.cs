﻿using System;
using System.Collections.Generic;
namespace Loop
{
    class ForEachLoop
    {
        public static void Main()
        {
            int sum = 0;
            int j = 10;
            int k = 1;
            for (int i = 0; i < j; i ++)
            {
                sum += k;
                k += 2;
            }
            Console.WriteLine($"Сумма чисел = {sum}");
        }
    }
}