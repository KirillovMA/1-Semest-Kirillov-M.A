﻿using System;
namespace Loop
{
    class ForEachLoop
    {
        public static void Main()
        {
            int[] num = { 24, 14, 64, 34, 23, 55, 236, 50, 44, 36 };
            foreach (int i in num)
                if (i > 20 && i < 50)
                Console.WriteLine(i);
          
        }
    }
}