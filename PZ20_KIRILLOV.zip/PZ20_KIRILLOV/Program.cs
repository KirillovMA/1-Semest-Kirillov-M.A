﻿using System;
namespace programm
{
    class Programm
    {
        static void Main()
        {
            int res = Sum();
            Console.WriteLine(res);
        }
        static int Sum()
        {
            int num = Convert.ToInt32(Console.ReadLine());
            if (num == 0)
                return 0;
            else
                return num + Sum();
        }
    }
}